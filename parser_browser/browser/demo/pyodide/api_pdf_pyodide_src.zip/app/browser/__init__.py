"""Browser/Pyodide integration package."""
